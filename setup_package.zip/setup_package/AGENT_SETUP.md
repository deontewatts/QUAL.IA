# OpenAI Auto‑Fix Agent — Setup Guide

## What this does

On every push to `main` or `develop`, a GitHub Action spins up an OpenAI agent (`gpt‑4o`) that inspects your codebase and intelligently applies fixes. It can correct syntax and logic errors, update dependencies, suggest refactorings and structural improvements, run formatters (Black for Python or Prettier for JS/TS), and perform security audits.

| Task          | Detail                                                             |
|---------------|---------------------------------------------------------------------|
| **Bug fixes** | Syntax errors, null references, async issues, logic bugs            |
| **Dep updates** | Flags outdated/insecure packages and fixes broken imports         |
| **Refactor**   | DRY, naming consistency, removal of dead code, shortens long functions |
| **Structure**  | Identifies misplaced files, missing exports, and cleans config      |
| **Formatting** | Auto‑runs Black (Python) or Prettier (JS/TS)                        |
| **Security**   | Runs `safety` (Python) or `npm audit` and saves the report          |

All fixes are automatically committed back to your branch with a clear commit message.

## Quick setup (3 steps)

1. **Add your OpenAI API key as a GitHub secret**

   - Navigate to your repository → **Settings → Secrets and variables → Actions**
   - Click **New repository secret**
   - Name the secret `OPENAI_API_KEY`
   - Value: your OpenAI API key (e.g., `sk-...`)

2. **Copy these files into your repo**

   ```text
   your-repo/
   ├── .github/
   │   └── workflows/
   │       └── ai-agent-fix.yml   ← the workflow
   ├── scripts/
   │   ├── ai_agent.py            ← the agent
   │   └── requirements.txt       ← agent dependencies
   └── AGENT_SETUP.md             ← this file
   ```

3. **Push to trigger**

   ```sh
   git add .
   git commit -m "feat: add OpenAI auto‑fix agent"
   git push origin main
   ```

The agent runs automatically. You can watch progress in the **Actions** tab.

## Manual trigger (run on demand)

Go to **Actions** → **OpenAI Agent - Auto Fix & Upgrade** → **Run workflow**. Choose a mode:

| Mode             | What it focuses on                                    |
|------------------|-------------------------------------------------------|
| `full`           | Everything — bugs, dependencies, refactors, structure |
| `deps-only`      | Dependency issues and broken imports only             |
| `bugs-only`      | Runtime errors and logic bugs only                    |
| `refactor-only`  | Code quality and DRY improvements only               |
| `structure-only` | File/folder organization only                         |

## Agent output files

After each run, a `.ai-agent/` folder is created (gitignored by default):

```
.ai-agent/
├── report.md            ← human‑readable summary of what changed
├── run-log.json         ← machine‑readable run metadata
├── security-report.json ← Python safety audit (if applicable)
└── npm-audit.json       ← npm audit results (if applicable)
```

The `report.md` is also posted to the GitHub Actions job summary so you can read it directly in the Actions UI.

Add `.ai-agent` to `.gitignore` if it isn't already:

```sh
echo ".ai-agent/" >> .gitignore
```

## NorCal Volley Intel — multiple repositories

To run this across all your repositories, add the workflow and scripts to each one. Alternatively, you can define the workflow once in a dedicated workflow repository and have each repo call it as a **GitHub reusable workflow**.

### Central workflow repo pattern

```
norcalvolley-workflows/
└── .github/
    └── workflows/
        └── ai-agent-fix.yml  ← define once, call from every repo
```

Then in each consuming repository:

```yaml
jobs:
  ai-fix:
    uses: your-org/norcalvolley-workflows/.github/workflows/ai-agent-fix.yml@main
    secrets: inherit
```

### Safety notes

- The agent adds `[skip ci]` to its commit message to prevent infinite loops.
- It never deletes files; it only rewrites existing ones or creates new ones it deems necessary.
- A maximum of 30 files are scanned per run (configurable via `MAX_FILES` in `ai_agent.py`).
- Files over 6,000 characters are truncated before being sent to OpenAI.
- All OpenAI calls are logged in `.ai-agent/run-log.json`.