#!/usr/bin/env python3
"""
NorCal Volley Intel - OpenAI Auto-Fix Agent

This utility analyzes repository code and applies intelligent fixes via the OpenAI API.
It collects a limited number of source files from the repository, prepares a prompt for
OpenAI based on the selected mode (full, deps-only, bugs-only, refactor-only, or
structure-only), parses the response, writes any corrected files back into place,
and records a human-readable report and machine‑readable log in the `.ai-agent` folder.
"""

import os
import sys
import json
import pathlib
import textwrap
from datetime import datetime
from openai import OpenAI

# ── Configuration ──────────────────────────────────────────────────────────────
# Instantiate the OpenAI client using the API key provided via environment.
client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

# Determine the fix mode, repository name, and project type from environment.
FIX_MODE = os.environ.get("FIX_MODE", "full")
REPO_NAME = os.environ.get("REPO_NAME", "unknown")
PROJECT_TYPE = os.environ.get("PROJECT_TYPE", "generic")

# Model and reporting configuration.
MODEL = "gpt-4o"
REPORT_DIR = pathlib.Path(".ai-agent")
REPORT_DIR.mkdir(exist_ok=True)

# Ignore certain directories and file types when scanning the repo.
SKIP_DIRS = {
    ".git",
    "node_modules",
    "__pycache__",
    ".venv",
    "dist",
    "build",
    ".ai-agent",
}
SKIP_EXTS = {
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".svg",
    ".ico",
    ".woff",
    ".woff2",
    ".ttf",
    ".eot",
    ".mp4",
    ".mp3",
    ".zip",
    ".tar",
    ".gz",
    ".lock",
}

# Limit how much data we send to OpenAI: max characters per file and total files.
MAX_FILE_CHARS = 6000
MAX_FILES = 30

# ── Mode instructions ──────────────────────────────────────────────────────────
# Each mode directs the agent to focus on different aspects of the codebase.
MODE_INSTRUCTIONS: dict[str, str] = {
    "full": textwrap.dedent(
        """
        You are a senior full-stack engineer doing a full audit. For EVERY file:
        1. Fix all bugs, syntax errors, and logic issues
        2. Update deprecated patterns to modern equivalents
        3. Refactor for clarity, DRY, and proper separation of concerns
        4. Improve error handling and add missing try/catch or guards
        5. Clean imports, remove dead code, and fix naming conventions
        6. Add brief docstrings/comments for complex functions
        7. Provide file/folder structure suggestions in the report
        """
    ),
    "deps-only": textwrap.dedent(
        """
        You are a dependency manager. Focus only on:
        1. Identifying outdated or deprecated package usage in code
        2. Flagging insecure dependencies
        3. Updating import paths if packages were renamed
        4. Removing unused imports
        """
    ),
    "bugs-only": textwrap.dedent(
        """
        You are a bug hunter. Focus only on:
        1. Runtime errors and unhandled exceptions
        2. Off-by-one errors and null/undefined dereferences
        3. Async/await issues and promise mishandling
        4. Logic errors and incorrect conditionals
        5. Missing return statements or wrong return types
        """
    ),
    "refactor-only": textwrap.dedent(
        """
        You are a refactoring expert. Focus only on:
        1. DRY violations — extract repeated code into functions/classes
        2. Long functions — break into smaller, single-responsibility units
        3. Magic numbers/strings — replace with named constants
        4. Inconsistent naming — standardize to the dominant convention
        5. Overly complex conditionals — simplify with early returns or guard clauses
        """
    ),
    "structure-only": textwrap.dedent(
        """
        You are an architect. Focus only on:
        1. Misplaced files — suggest correct locations
        2. Missing index files or barrel exports
        3. Inconsistent folder naming conventions
        4. Missing or outdated README/docs references
        5. Config files that should be centralized
        """
    ),
}

# ── Helper functions ───────────────────────────────────────────────────────────
def collect_files(root: pathlib.Path) -> list[pathlib.Path]:
    """Recursively gather all files from the repository, skipping ignored dirs and extensions."""
    files: list[pathlib.Path] = []
    for p in root.rglob("*"):
        if p.is_file():
            if any(skip in p.parts for skip in SKIP_DIRS):
                continue
            if p.suffix.lower() in SKIP_EXTS:
                continue
            files.append(p)
    return sorted(files)[:MAX_FILES]


def read_file_safe(p: pathlib.Path) -> str:
    """Read a file with UTF‑8 encoding; truncate if it exceeds the character limit."""
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
        if len(text) > MAX_FILE_CHARS:
            text = text[:MAX_FILE_CHARS] + f"\n... [TRUNCATED at {MAX_FILE_CHARS}]"
        return text
    except Exception as e:
        return f"[ERROR reading file: {e}]"


def build_file_bundle(files: list[pathlib.Path], root: pathlib.Path) -> str:
    """Construct the payload that will be sent to OpenAI for analysis."""
    parts: list[str] = []
    for p in files:
        rel = p.relative_to(root)
        content = read_file_safe(p)
        parts.append(f"### FILE: {rel}\n```\n{content}\n```")
    return "\n\n".join(parts)


def call_openai(system_prompt: str, user_content: str) -> str:
    """Send a chat completion request to OpenAI and return the response content."""
    print(f"  → Calling {MODEL}... ", end="", flush=True)
    response = client.chat.completions.create(
        model=MODEL,
        temperature=0.15,
        max_tokens=4096,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ],
    )
    result = response.choices[0].message.content
    print(f"done ({response.usage.total_tokens} tokens)")
    return result


def parse_fixes(raw: str) -> dict[str, str]:
    """
    Parse the JSON returned by OpenAI.

    The expected structure is:
    {
      "fixes": { "relative/path.py": "<updated file content>", ... },
      "summary": "markdown summary"
    }
    If parsing fails, return an empty fixes dict and the raw (trimmed) summary.
    """
    try:
        clean = raw.strip()
        # Remove markdown fences if present
        if clean.startswith("```"):
            clean = clean.split("\n", 1)[1]
        if clean.endswith("```"):
            clean = clean.rsplit("```", 1)[0]
        data = json.loads(clean)
        return data  # type: ignore[return-value]
    except Exception as e:
        print(f"  ⚠ Could not parse JSON response: {e}")
        return {"fixes": {}, "summary": raw[:2000]}


# ── Main workflow ─────────────────────────────────────────────────────────────
def main() -> None:
    # Print high‑level run context
    print(f"\n NorCal Volley Intel AI Agent")
    print(f"   Repo   : {REPO_NAME}")
    print(f"   Mode   : {FIX_MODE}")
    print(f"   Project: {PROJECT_TYPE}")
    print(f"   Time   : {datetime.utcnow().isoformat()}Z\n")

    root = pathlib.Path(".")
    files = collect_files(root)
    print(f"Collected {len(files)} files for analysis")
    if not files:
        print("⚠ No files found. Exiting.")
        sys.exit(0)

    # Build prompt and input bundle
    bundle = build_file_bundle(files, root)
    file_list = "\n".join(f"  - {f.relative_to(root)}" for f in files)
    instructions = MODE_INSTRUCTIONS.get(FIX_MODE, MODE_INSTRUCTIONS["full"])
    system_prompt = textwrap.dedent(
        f"""
        You are an expert software engineer doing a code review and fix pass.
        Repository: {REPO_NAME}
        Project type: {PROJECT_TYPE}
        Fix mode: {FIX_MODE}
        {instructions}
        RESPONSE FORMAT — you MUST return valid JSON only, no prose outside JSON:
        {{
          "fixes": {{
            "relative/path/to/file": "...complete corrected file content (not a diff)...",
            "another/file.js": "..."
          }},
          "summary": "## AI Agent Report\\n\\n### What was fixed\\n...\\n### File suggestions\\n..."
        }}
        Rules:
        - Only include files you ACTUALLY changed in "fixes"
        - "fixes" values must be the FULL corrected file content (not diffs or snippets)
        - Keep the "summary" as clean markdown
        - Do not fabricate new features unless mode is "full"
        - If a file is fine, omit it from "fixes"
        - Never delete critical config files
        """
    ).strip()

    user_content = f"""
Here are the repository files to analyze and fix:
Files included:
{file_list}
---
{bundle}
""".strip()

    print(f"\n Sending to OpenAI ({FIX_MODE} mode)...")
    raw_response = call_openai(system_prompt, user_content)
    print("\n Parsing and applying fixes...")
    result = parse_fixes(raw_response)
    fixes = result.get("fixes", {})
    summary = result.get("summary", "No summary provided.")
    applied = 0
    errors = 0

    # Apply returned fixes
    for rel_path, content in fixes.items():
        target = root / rel_path
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
            print(f"   Fixed: {rel_path}")
            applied += 1
        except Exception as e:
            print(f"   Failed to write {rel_path}: {e}")
            errors += 1

    # Ensure report directory exists and write report
    REPORT_DIR.mkdir(exist_ok=True)
    report_path = REPORT_DIR / "report.md"
    report_content = (
        f"## AI Agent Report — {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%SZ')}\n\n"
        f"**Mode:** `{FIX_MODE}` | **Project:** `{PROJECT_TYPE}` | **Files scanned:** {len(files)}\n"
        f"**Files fixed:** {applied} | **Errors:** {errors}\n"
        f"---\n"
        f"{summary}\n"
    )
    report_path.write_text(report_content, encoding="utf-8")
    print(f"\n Report saved to {report_path}")

    # Write machine-readable log
    log = {
        "timestamp": datetime.utcnow().isoformat(),
        "repo": REPO_NAME,
        "mode": FIX_MODE,
        "project_type": PROJECT_TYPE,
        "files_scanned": len(files),
        "files_fixed": applied,
        "errors": errors,
        "files_changed": list(fixes.keys()),
    }
    (REPORT_DIR / "run-log.json").write_text(json.dumps(log, indent=2))
    print(f"\n Done! Applied {applied} fixes across {len(files)} files.")
    if errors:
        print(f"⚠ {errors} files had write errors — check permissions.")


if __name__ == "__main__":
    main()